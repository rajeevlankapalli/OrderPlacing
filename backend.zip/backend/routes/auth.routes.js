import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken"; 
import { prisma } from "../server.js";

const router = Router();


router.post("/register", async (req, res) => {
    try{
        const { name, email, phone, password } = req.body;
    if (!name || !email || !password)
        return res.status(400).json({ error: "name, email, password required" });

    const emailLc = email.toLowerCase();
    const exists = await prisma.customer.findUnique({ where: { email: emailLc } });
    if (exists) return res.status(409).json({ error: "Email already exists" });

    const passwordHash = await bcrypt.hash(password, 10);
    const row = await prisma.customer.create({
        data: { name, email: emailLc, phone: phone || null, passwordHash },
        select: { id: true, name: true, email: true, phone: true, createdAt: true },
    });
    res.status(201).json(row);
    }catch (err) {
        console.error("GET /customers error:", err);
        res.status(500).json({ error: "Internal server error" });  
        }
  
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: "email and password required" });

    const emailLc = email.toLowerCase();
    const user = await prisma.customer.findUnique({ where: { email: emailLc } });
    if (!user) return res.status(404).json({ error: "User not found" });

    // compare password
    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "Invalid password" });

    // sign JWT
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET || "changeme",
      { expiresIn: "2h" }
    );

    res.json({
      token,
      customer: { id: user.id, name: user.name, email: user.email, phone: user.phone },
    });
  } catch (err) {
    console.error("POST /auth/login error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/exists", async (req, res) => {
  const email = (req.query.email || "").toLowerCase().trim();
  if (!email) return res.status(400).json({ error: "Email required" });

  const user = await prisma.customer.findUnique({ where: { email } });
  res.json({ exists: !!user });
});

export default router;
