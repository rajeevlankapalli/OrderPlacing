import { Router } from "express";
import jwt from "jsonwebtoken";
import { prisma } from "../server.js";

const router = Router();

function requireAuth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    const p = jwt.verify(token, process.env.JWT_SECRET || "changeme");
    req.user = { id: p.id, email: p.email };
    next();
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
}

// GET /addresses  (mine)
router.get("/", requireAuth, async (req, res) => {
  const rows = await prisma.address.findMany({
    where: { customerId: req.user.id },
    orderBy: [{ isDefault: "desc" }, { id: "desc" }],
    select: {
      id: true, line1: true, line2: true, city: true, state: true,
      postalCode: true, country: true, isDefault: true, createdAt: true
    },
  });
  res.json(rows);
});

// POST /addresses  (create; optional isDefault=true)
router.post("/", requireAuth, async (req, res) => {
  const { line1, line2, city, state, postalCode, country = "India", isDefault } = req.body || {};
  if (!line1 || !city || !postalCode) {
    return res.status(400).json({ error: "line1, city, postalCode required" });
  }

  const created = await prisma.$transaction(async (tx) => {
    if (isDefault === true) {
      await tx.address.updateMany({
        where: { customerId: req.user.id, isDefault: true },
        data: { isDefault: false },
      });
    }
    return tx.address.create({
      data: { customerId: req.user.id, line1, line2, city, state, postalCode, country, isDefault: !!isDefault },
      select: {
        id: true, line1: true, line2: true, city: true, state: true,
        postalCode: true, country: true, isDefault: true, createdAt: true
      },
    });
  });

  res.status(201).json(created);
});

// PUT /addresses/:id  (update; can toggle default)
router.put("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const cur = await prisma.address.findFirst({ where: { id, customerId: req.user.id } });
  if (!cur) return res.status(404).json({ error: "Not found" });

  const { line1, line2, city, state, postalCode, country, isDefault } = req.body || {};

  const updated = await prisma.$transaction(async (tx) => {
    if (isDefault === true) {
      await tx.address.updateMany({
        where: { customerId: req.user.id, isDefault: true },
        data: { isDefault: false },
      });
    }
    return tx.address.update({
      where: { id },
      data: {
        ...(line1 !== undefined ? { line1 } : {}),
        ...(line2 !== undefined ? { line2 } : {}),
        ...(city !== undefined ? { city } : {}),
        ...(state !== undefined ? { state } : {}),
        ...(postalCode !== undefined ? { postalCode } : {}),
        ...(country !== undefined ? { country } : {}),
        ...(isDefault !== undefined ? { isDefault: !!isDefault } : {}),
      },
      select: {
        id: true, line1: true, line2: true, city: true, state: true,
        postalCode: true, country: true, isDefault: true, createdAt: true
      },
    });
  });

  res.json(updated);
});

// DELETE /addresses/:id  (mine)
router.delete("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const cur = await prisma.address.findFirst({ where: { id, customerId: req.user.id } });
  if (!cur) return res.status(404).json({ error: "Not found" });

  await prisma.address.delete({ where: { id } });
  res.json({ ok: true });
});

export default router;
