import { Router } from "express";
import jwt from "jsonwebtoken";
import { prisma } from "../server.js";
import { Prisma } from "../generated/prisma/index.js";

const router = Router(); 

function requireAuth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "No token" });
  try {
    const p = jwt.verify(token, process.env.JWT_SECRET || "changeme");
    req.user = { id: p.id, email: p.email };
    next();
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
}

router.get("/", requireAuth, async (req, res) => {
  const list = await prisma.order.findMany({
    where: { customerId: req.user.id }, // ← comes from token
    include: {
      address: true,
      items: { include: { item: { select: { id: true, name: true, sku: true } } } },
    },
    orderBy: { id: "desc" },
  });
  res.json(list);
});

router.get("/:id", requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  const row = await prisma.order.findFirst({
    where: { id, customerId: req.user.id },
    include: {
      address: true,
      items: { include: { item: { select: { id: true, name: true, sku: true } } } },
    },
  });
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

router.post("/", requireAuth, async (req, res) => {
  const body = req.body || {};
  const lines = Array.isArray(body.items) ? body.items : [];

  // ✅ require an address (either addressId or inline address)
  const addressIdRaw = body.addressId;
  const addressObj = body.address;

  if (!addressIdRaw && !(addressObj && addressObj.line1 && addressObj.city && addressObj.postalCode)) {
    return res.status(400).json({ error: "addressId or address { line1, city, postalCode } is required" });
  }

  if (lines.length === 0) return res.status(400).json({ error: "items required" });

  try {
    const sanitized = lines.map(l => ({
      itemId: Number(l.itemId),
      quantity: Math.max(1, Number(l.quantity || 1)),
    }));

    // validate items + stock
    const ids = sanitized.map(l => l.itemId);
    const dbItems = await prisma.item.findMany({
      where: { id: { in: ids }, isActive: true },
      select: { id: true, name: true, price: true, stock: true },
    });
    if (dbItems.length !== ids.length) return res.status(400).json({ error: "Some items are invalid or inactive" });

    for (const l of sanitized) {
      const it = dbItems.find(d => d.id === l.itemId);
      if (!it) return res.status(400).json({ error: `Invalid item ${l.itemId}` });
      if (it.stock < l.quantity) return res.status(400).json({ error: `Insufficient stock for ${it.name}` });
    }

    // totals
    const orderItemsData = sanitized.map(l => {
      const it = dbItems.find(d => d.id === l.itemId);
      const unitPrice = new Prisma.Decimal(it.price);
      const qty = new Prisma.Decimal(l.quantity);
      const lineTotal = unitPrice.mul(qty);
      return { itemId: it.id, quantity: l.quantity, unitPrice, lineTotal };
    });
    const totalAmount = orderItemsData.reduce((a, li) => a.plus(li.lineTotal), new Prisma.Decimal(0));

    // resolve/create address
    let addressId = addressIdRaw ? Number(addressIdRaw) : null;
    if (addressId) {
      const ok = await prisma.address.findFirst({ where: { id: addressId, customerId: req.user.id } });
      if (!ok) return res.status(400).json({ error: "Invalid addressId" });
    }

    const order = await prisma.$transaction(async (tx) => {
      // create address inline if needed
      if (!addressId && addressObj) {
        if (addressObj.isDefault === true) {
          await tx.address.updateMany({
            where: { customerId: req.user.id, isDefault: true },
            data: { isDefault: false },
          });
        }
        const createdAddr = await tx.address.create({
          data: {
            customerId: req.user.id,
            line1: addressObj.line1,
            line2: addressObj.line2 || null,
            city: addressObj.city,
            state: addressObj.state || null,
            postalCode: addressObj.postalCode,
            country: addressObj.country || "India",
            isDefault: !!addressObj.isDefault,
          },
        });
        addressId = createdAddr.id;
      }

      // decrement stock
      for (const l of sanitized) {
        await tx.item.update({
          where: { id: l.itemId },
          data: { stock: { decrement: l.quantity } },
        });
      }

      // create order
      const created = await tx.order.create({
        data: {
          customerId: req.user.id,
          addressId,
          totalAmount,
          items: { create: orderItemsData },
        },
        include: {
          address: true,
          items: { include: { item: { select: { id: true, name: true, sku: true } } } },
        },
      });

      return created;
    });

    res.status(201).json(order);
  } catch (e) {
    console.error("POST /orders error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
