import { Router } from "express";
import { prisma } from "../server.js";

const router = Router();

/** helpers */
function normalizeSKU(sku) {
  return typeof sku === "string" ? sku.trim().toUpperCase() : null;
}
function normalizeName(name) {
  return typeof name === "string" ? name.trim() : "";
}
function toPriceString(price) {
  if (price === null || price === undefined) return null;
  const n = typeof price === "number" ? price : Number(String(price).trim());
  if (!Number.isFinite(n) || n < 0) return null;
  return n.toFixed(2);
}


router.get("/", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const page = Math.max(1, Number(req.query.page || 1) || 1);
  const size = Math.min(50, Math.max(1, Number(req.query.size || 10) || 10));
  const includeAll = String(req.query.all || "0") === "1";

  const where = {
    ...(q
      ? {
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { sku: { contains: q, mode: "insensitive" } },
          ],
        }
      : {}),
    ...(!includeAll ? { isActive: true } : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.item.findMany({
      where,
      orderBy: [{ id: "asc" }],
      skip: (page - 1) * size,
      take: size,
      select: { id: true, sku: true, name: true, price: true,stock:true, isActive: true, createdAt: true },
    }),
    prisma.item.count({ where }),
  ]);

  res.json({ page, size, total, hasNext: page * size < total, rows });
});

/** GET /items/:id */
router.get("/:id", async (req, res) => {
  const id = Number(req.params.id);
  const row = await prisma.item.findUnique({
    where: { id },
    select: { id: true, sku: true, name: true, price: true, isActive: true, createdAt: true },
  });
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});


router.post("/", async (req, res) => {
  const name = normalizeName(req.body.name);
  const priceStr = toPriceString(req.body.price);
  const sku = normalizeSKU(req.body.sku);
  const isActive = req.body.isActive === false ? false : true; 

  if (!name || !priceStr) {
    return res.status(400).json({ error: "name and price are required (price >= 0)" });
  }
  const stock = Number(req.body.stock ?? 0);
  if (stock < 0) return res.status(400).json({ error: "stock cannot be negative" });

  try {
    const created = await prisma.item.create({
      data: { name, price: priceStr, sku, isActive, stock  },
      select: { id: true, sku: true, name: true, price: true,stock: true, isActive: true, createdAt: true },
    });
    res.status(201).json(created);
  } catch (e) {

    if (e?.code === "P2002" && e?.meta?.target?.includes("sku")) {
      return res.status(409).json({ error: "SKU already exists" });
    }
    console.error("POST /items error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});


router.put("/:id", async (req, res) => {
  const id = Number(req.params.id);
  const data = {};

  if (req.body.name !== undefined) {
    const nm = normalizeName(req.body.name);
    if (!nm) return res.status(400).json({ error: "name cannot be empty" });
    data.name = nm;
  }
  if (req.body.price !== undefined) {
    const priceStr = toPriceString(req.body.price);
    if (!priceStr) return res.status(400).json({ error: "Invalid price" });
    data.price = priceStr;
  }
  if (req.body.sku !== undefined) {
    data.sku = normalizeSKU(req.body.sku);
  }
  if (req.body.isActive !== undefined) {
    data.isActive = !!req.body.isActive;
  }
  if (req.body.stock !== undefined) {
  const stock = Number(req.body.stock);
  if (!Number.isInteger(stock) || stock < 0) {
    return res.status(400).json({ error: "stock must be a non-negative integer" });
  }
  data.stock = stock;
}

  try {
    const updated = await prisma.item.update({
      where: { id },
      data,
      select: { id: true, sku: true, name: true, price: true,stock: true, isActive: true, createdAt: true },
    });
    res.json(updated);
  } catch (e) {
    if (e?.code === "P2002" && e?.meta?.target?.includes("sku")) {
      return res.status(409).json({ error: "SKU already exists" });
    }
    if (e?.code === "P2025") {
      return res.status(404).json({ error: "Item not found" });
    }
    console.error("PUT /items/:id error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

/** DELETE /items/:id  (dev only; consider soft-delete in prod) */
router.delete("/:id", async (req, res) => {
  const id = Number(req.params.id);
  try {
    await prisma.item.delete({ where: { id } });
    res.json({ ok: true });
  } catch (e) {
    if (e?.code === "P2025") return res.status(404).json({ error: "Item not found" });
    console.error("DELETE /items/:id error:", e);
    res.status(500).json({ error: "Internal server error" });
  }
});

/** (Optional) quick seed for dev */
router.post("/seed", async (_req, res) => {
  const demo = [
    { name: "Apple", price: "30.00", sku: "APL-001" },
    { name: "Banana", price: "10.00", sku: "BAN-001" },
    { name: "Milk 1L", price: "55.00", sku: "MLK-001" },
  ];
  const out = [];
  for (const it of demo) {
    const row = await prisma.item.upsert({
      where: { sku: it.sku },
      update: { name: it.name, price: it.price, isActive: true },
      create: it,
      select: { id: true, sku: true, name: true, price: true, isActive: true, createdAt: true },
    });
    out.push(row);
  }
  res.json(out);
});

export default router;
