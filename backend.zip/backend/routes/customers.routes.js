import { Router } from "express";
import bcrypt from "bcryptjs";
import { prisma } from "../server.js";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const qRaw = (req.query.q ?? "").toString();
    const q = qRaw.length > 100 ? qRaw.slice(0, 100).trim() : qRaw.trim();
    const page = Math.max(1, Number(req.query.page || 1) || 1);
    const size = Math.min(50, Math.max(1, Number(req.query.size || 10) || 10));

    const where = q
      ? {
          OR: [
            { name:  { contains: q, mode: "insensitive" } },
            { email: { contains: q, mode: "insensitive" } },
            { phone: { contains: q, mode: "insensitive" } },
          ],
        }
      : {};

    const [rows, total] = await Promise.all([
      prisma.customer.findMany({
        where,
        orderBy: { id: "desc" },
        skip: (page - 1) * size,
        take: size,
        select: { id: true, name: true, email: true, phone: true, createdAt: true },
      }),
      prisma.customer.count({ where }),
    ]);

    res.json({
      page,
      size,
      total,
      hasNext: page * size < total,
      rows,
    });
  } catch (err) {
    console.error("GET /customers error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});


/** GET /customers/:id */
router.get("/:id", async (req, res) => {
  const id = Number(req.params.id);
  const c = await prisma.customer.findUnique({
    where: { id },
    select: { id: true, name: true, email: true, phone: true, createdAt: true },
  });
  if (!c) return res.status(404).json({ error: "Not found" });
  res.json(c);
});

/**
 * POST /customers
 * Body: { name, email, phone?, password }
 */
router.post("/", async (req, res) => {
    try{
        const { name, email, phone, password } = req.body;
    if (!name || !email || !password)
        return res.status(400).json({ error: "name, email, password required" });

    const emailLc = email.toLowerCase();
    const exists = await prisma.customer.findUnique({ where: { email: emailLc } });
    if (exists) return res.status(409).json({ error: "Email already exists" });

    const passwordHash = await bcrypt.hash(password, 10);
    const row = await prisma.customer.create({
        data: { name, email: emailLc, phone: phone || null, passwordHash },
        select: { id: true, name: true, email: true, phone: true, createdAt: true },
    });
    res.status(201).json(row);
    }catch (err) {
        console.error("GET /customers error:", err);
        res.status(500).json({ error: "Internal server error" });  
        }
  
});



router.put("/:id", async (req, res) => {
  const id = Number(req.params.id);
  const { name, phone, password } = req.body;

  const data = {};
  if (typeof name === "string") data.name = name;
  if (typeof phone === "string") data.phone = phone;
  if (password) data.passwordHash = await bcrypt.hash(password, 10);

  const row = await prisma.customer.update({
    where: { id },
    data,
    select: { id: true, name: true, email: true, phone: true, createdAt: true },
  });
  res.json(row);
});

/** DELETE /customers/:id  (dev only) */
router.delete("/:id", async (req, res) => {
  const id = Number(req.params.id);
  await prisma.customer.delete({ where: { id } });
  res.json({ ok: true });
});

export default router;
