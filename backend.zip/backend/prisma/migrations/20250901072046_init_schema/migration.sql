-- AlterTable
ALTER TABLE "public"."Item" ADD COLUMN     "stock" INTEGER NOT NULL DEFAULT 0;
