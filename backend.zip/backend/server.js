import express from "express";
import cors from "cors";
import dotenv from "dotenv";


import { PrismaClient } from "./generated/prisma/index.js";
import authRoutes from "./routes/auth.routes.js";
import customersRoutes from "./routes/customers.routes.js";
import itemsRoutes from "./routes/items.routes.js";
import addressesRoutes from "./routes/addresses.routes.js";
import ordersRoutes from "./routes/orders.routes.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Export prisma so routes can reuse it
export const prisma = new PrismaClient();



// Mount routes
app.use("/auth", authRoutes); 
app.use("/customers", customersRoutes);
app.use("/items", itemsRoutes);
app.use("/addresses", addressesRoutes);
app.use("/orders", ordersRoutes) 

// 404 fallback (optional)
app.use((req, res) => res.status(404).json({ error: "Not found" }));

const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`API running on http://localhost:${port}`);
});
