import { useState } from "react";
import QuantityInput from "./QuantityInput";
import { useCart } from "../context/CartContext";

export default function ItemCard({ item }) {
  const { add } = useCart();
  const [qty, setQty] = useState(1);
  const outOfStock = item.stock <= 0;
  const max = item.stock;

  return (
    <div className="bg-white border rounded-xl p-4 flex flex-col justify-between shadow-sm">
      <div>
        <div className="text-sm text-gray-500">{item.sku}</div>
        <div className="mt-1 font-semibold">{item.name}</div>
        <div className="mt-1 text-indigo-700 font-bold">₹ {Number(item.price).toLocaleString()}</div>
        <div className={`mt-2 inline-block text-xs px-2 py-1 rounded-full ${
          outOfStock ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"
        }`}>
          {outOfStock ? "Out of stock" : `In stock: ${item.stock}`}
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <QuantityInput value={qty} onChange={setQty} max={max} />
        <button
          className="ml-3 px-3 py-2 rounded-lg text-white bg-indigo-600 disabled:opacity-50"
          disabled={outOfStock || qty < 1}
          onClick={() => add(item, qty)}
          title={outOfStock ? "No stock" : "Add to cart"}
        >
          Add
        </button>
      </div>
    </div>
  );
}
