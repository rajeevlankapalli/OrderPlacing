export default function QuantityInput({ value, onChange, max = 999, min = 1 }) {
  return (
    <div className="inline-flex items-center rounded-lg border">
      <button
        type="button"
        className="px-2 py-1 text-gray-700 disabled:opacity-40"
        onClick={() => onChange(Math.max(min, (Number(value)||1) - 1))}
        disabled={Number(value) <= min}
      >−</button>
      <input
        className="w-12 text-center outline-none"
        value={value}
        onChange={e => {
          const v = e.target.value.replace(/\D/g,'');
          onChange(v === "" ? "" : Math.min(Number(v), max));
        }}
      />
      <button
        type="button"
        className="px-2 py-1 text-gray-700 disabled:opacity-40"
        onClick={() => onChange(Math.min(max, (Number(value)||0) + 1))}
        disabled={Number(value) >= max}
      >+</button>
    </div>
  );
}
