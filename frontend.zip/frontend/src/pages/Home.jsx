export default function Home() {
  const user = (() => {
    try { return JSON.parse(localStorage.getItem("user") || "{}"); }
    catch { return {}; }
  })();

  return (
    <div className="px-4 py-14">
      <div className="max-w-3xl mx-auto rounded-2xl bg-white/90 p-8 shadow-2xl backdrop-blur">
        <h1 className="text-2xl font-semibold text-gray-800">
          Hello{user?.name ? `, ${user.name}` : ""}! 🎉
        </h1>
        <p className="text-gray-600 mt-2">
          You’re logged in. Next we’ll add Items, Addresses and Orders.
        </p>
      </div>
    </div>
  );
}
