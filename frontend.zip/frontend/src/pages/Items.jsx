import { useEffect, useState } from "react";
import api from "../api/client";
import ItemCard from "../components/ItemCard";
import Layout from "../layout/Layout";

export default function Items() {
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [size] = useState(12);
  const [data, setData] = useState({ rows: [], total: 0, hasNext: false });

  useEffect(() => { fetchItems();  }, [page]);

  async function fetchItems() {
    const r = await api.get(`/items?q=${encodeURIComponent(q)}&page=${page}&size=${size}`);
    setData(r.data);
  }

  function onSearch(e) {
    e.preventDefault();
    setPage(1);
    fetchItems();
  }

  return (
    <Layout>
      <div className="flex items-center justify-between mb-4">
        <form onSubmit={onSearch} className="flex items-center gap-2">
          <input
            className="rounded-lg border px-3 py-2 w-72"
            placeholder="Search items or SKU…"
            value={q}
            onChange={(e)=>setQ(e.target.value)}
          />
          <button className="px-3 py-2 rounded-lg bg-gray-900 text-white">Search</button>
        </form>
        <div className="text-sm text-gray-600">Total: {data.total}</div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {data.rows.map(it => <ItemCard key={it.id} item={it} />)}
      </div>

      <div className="mt-6 flex items-center justify-center gap-2">
        <button
          className="px-3 py-1.5 rounded-lg border disabled:opacity-50"
          disabled={page === 1}
          onClick={()=>setPage(p=>Math.max(1, p-1))}
        >Previous</button>
        <span className="text-sm">Page {page}</span>
        <button
          className="px-3 py-1.5 rounded-lg border disabled:opacity-50"
          disabled={!data.hasNext}
          onClick={()=>setPage(p=>p+1)}
        >Next</button>
      </div>
    </Layout>
  );
}
