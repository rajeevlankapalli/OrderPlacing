import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Layout from "../layout/Layout";
import api from "../api/client";

export default function Orders() {
  const [rows, setRows] = useState([]);

  useEffect(() => { (async () => {
    const r = await api.get("/orders");
    setRows(r.data || []);
  })(); }, []);

  return (
    <Layout>
      <div className="bg-white rounded-xl border p-4">
        <h2 className="text-lg font-semibold">My Orders</h2>
        {rows.length === 0 ? (
          <p className="text-gray-500 mt-2">No orders yet.</p>
        ) : (
          <ul className="mt-2 divide-y">
            {rows.map(o => (
              <li key={o.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="font-medium">Order #{o.id}</div>
                  <div className="text-sm text-gray-600">
                    Placed: {new Date(o.createdAt).toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-700">
                    Items: {o.items?.reduce((a, it) => a + it.quantity, 0) ?? 0}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-indigo-700">₹ {Number(o.totalAmount).toLocaleString()}</div>
                  <Link className="text-sm underline" to={`/orders/${o.id}`}>View details</Link>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Layout>
  );
}
