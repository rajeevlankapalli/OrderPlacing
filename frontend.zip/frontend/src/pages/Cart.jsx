import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Layout from "../layout/Layout";
import { useCart } from "../context/CartContext";
import api from "../api/client";

const USE_ADDRESS_API = true; // address required by backend

export default function Cart() {
  const { items, setQty, remove, clear, totals } = useCart();
  const nav = useNavigate();

  const [msg, setMsg] = useState("");
  const [placing, setPlacing] = useState(false);

  // addresses
  const [addresses, setAddresses] = useState([]);
  const [addressMode, setAddressMode] = useState("existing"); // 'existing' | 'new'
  const [addressId, setAddressId] = useState(null);

  // new address form
  const [addr, setAddr] = useState({
    line1: "",
    line2: "",
    city: "",
    state: "",
    postalCode: "",
    country: "India",
    isDefault: false,
  });

  // success popup
  const [successOrder, setSuccessOrder] = useState(null); // holds created order

  // load my addresses
  useEffect(() => {
    if (!USE_ADDRESS_API) return;
    (async () => {
      try {
        const r = await api.get("/addresses");
        const rows = r.data || [];
        setAddresses(rows);
        if (rows.length > 0) {
          const def = rows.find(a => a.isDefault) || rows[0];
          setAddressMode("existing");
          setAddressId(def.id);
        } else {
          setAddressMode("new");
          setAddressId(null);
        }
      } catch (e) {
        console.error("load addresses error", e);
      }
    })();
  }, []);

  async function placeOrder() {
    setMsg("");
    if (items.length === 0) return setMsg("Cart is empty");

    // Prepare payload with address
    let payload = {
      items: items.map(i => ({ itemId: i.itemId, quantity: i.qty })),
    };

    if (USE_ADDRESS_API) {
      if (addressMode === "existing") {
        if (!addressId) return setMsg("Please select an address");
        payload.addressId = addressId;
      } else {
        // new address inline
        if (!addr.line1 || !addr.city || !addr.postalCode) {
          return setMsg("Please fill address: line1, city, postalCode");
        }
        payload.address = {
          line1: addr.line1.trim(),
          line2: addr.line2?.trim() || "",
          city: addr.city.trim(),
          state: addr.state?.trim() || "",
          postalCode: addr.postalCode.trim(),
          country: addr.country?.trim() || "India",
          isDefault: !!addr.isDefault,
        };
      }
    }

    setPlacing(true);
    try {
      const r = await api.post("/orders", payload);
      clear();
      setSuccessOrder(r.data); // show popup with order id
      setMsg("");
    } catch (e) {
      setMsg(e?.response?.data?.error || "Failed to place order");
    } finally {
      setPlacing(false);
    }
  }

  return (
    <Layout>
      <div className="grid md:grid-cols-[1fr_360px] gap-6">
        {/* Cart items */}
        <div className="bg-white rounded-xl border p-4">
          <h2 className="text-lg font-semibold">Cart</h2>
          {items.length === 0 ? (
            <p className="text-gray-500 mt-2">Your cart is empty.</p>
          ) : (
            <ul className="divide-y">
              {items.map(it => (
                <li key={it.itemId} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium">{it.name}</div>
                    <div className="text-xs text-gray-500">{it.sku}</div>
                    <div className="text-sm text-gray-600">₹ {it.unitPrice.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Stock left: {it.stock - it.qty}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      className="w-16 text-center rounded-lg border px-2 py-1"
                      value={it.qty}
                      onChange={e => {
                        const v = e.target.value.replace(/\D/g, "");
                        if (v === "") return setQty(it.itemId, 0);
                        setQty(it.itemId, Math.min(Number(v), it.stock));
                      }}
                    />
                    <button className="px-2 py-1 rounded-lg border" onClick={() => remove(it.itemId)}>
                      Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Summary + Address */}
        <div className="bg-white rounded-xl border p-4 h-fit">
          <h2 className="text-lg font-semibold">Summary</h2>
          <div className="mt-2 text-sm text-gray-700">Items: {totals.totalQty}</div>
          <div className="mt-1 font-semibold text-indigo-700">
            Total: ₹ {totals.totalAmount.toLocaleString()}
          </div>

          {USE_ADDRESS_API && (
            <>
              <h3 className="mt-4 font-medium">Delivery Address</h3>

              {/* Mode selector appears only if I already have addresses */}
              {addresses.length > 0 && (
                <div className="mt-2 flex gap-3 text-sm">
                  <label className="inline-flex items-center gap-2">
                    <input
                      type="radio"
                      name="addrMode"
                      checked={addressMode === "existing"}
                      onChange={() => setAddressMode("existing")}
                    />
                    Use existing
                  </label>
                  <label className="inline-flex items-center gap-2">
                    <input
                      type="radio"
                      name="addrMode"
                      checked={addressMode === "new"}
                      onChange={() => setAddressMode("new")}
                    />
                    New address
                  </label>
                </div>
              )}

              {/* Existing addresses list */}
              {addressMode === "existing" && addresses.length > 0 && (
                <ul className="mt-3 space-y-2">
                  {addresses.map(a => (
                    <li key={a.id} className="rounded-lg border p-3 flex items-start gap-3">
                      <input
                        type="radio"
                        name="addressId"
                        checked={addressId === a.id}
                        onChange={() => setAddressId(a.id)}
                        className="mt-1"
                      />
                      <div>
                        <div className="text-sm font-medium">
                          {a.line1}{a.line2 ? `, ${a.line2}` : ""}, {a.city}
                        </div>
                        <div className="text-xs text-gray-600">
                          {a.state ? `${a.state}, ` : ""}{a.country} — {a.postalCode}
                        </div>
                        {a.isDefault && (
                          <span className="mt-1 inline-block text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                            Default
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}

              {/* New address form */}
              {addressMode === "new" && (
                <div className="mt-3 grid grid-cols-1 gap-2">
                  <input
                    className="rounded-lg border px-3 py-2"
                    placeholder="Line 1 *"
                    value={addr.line1}
                    onChange={e => setAddr(a => ({ ...a, line1: e.target.value }))}
                  />
                  <input
                    className="rounded-lg border px-3 py-2"
                    placeholder="Line 2"
                    value={addr.line2}
                    onChange={e => setAddr(a => ({ ...a, line2: e.target.value }))}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      className="rounded-lg border px-3 py-2"
                      placeholder="City *"
                      value={addr.city}
                      onChange={e => setAddr(a => ({ ...a, city: e.target.value }))}
                    />
                    <input
                      className="rounded-lg border px-3 py-2"
                      placeholder="State"
                      value={addr.state}
                      onChange={e => setAddr(a => ({ ...a, state: e.target.value }))}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      className="rounded-lg border px-3 py-2"
                      placeholder="Postal Code *"
                      value={addr.postalCode}
                      onChange={e => setAddr(a => ({ ...a, postalCode: e.target.value }))}
                    />
                    <input
                      className="rounded-lg border px-3 py-2"
                      placeholder="Country"
                      value={addr.country}
                      onChange={e => setAddr(a => ({ ...a, country: e.target.value }))}
                    />
                  </div>
                  <label className="mt-1 inline-flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={addr.isDefault}
                      onChange={e => setAddr(a => ({ ...a, isDefault: e.target.checked }))}
                    />
                    Make this my default address
                  </label>
                </div>
              )}
            </>
          )}

          <button
            className="mt-4 w-full rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white py-2.5 disabled:opacity-50 flex items-center justify-center gap-2"
            onClick={placeOrder}
            disabled={placing || items.length === 0}
          >
            {placing && (
              <span className="inline-block w-4 h-4 rounded-full border-2 border-white/60 border-t-transparent animate-spin" />
            )}
            {placing ? "Placing..." : "Place Order"}
          </button>

          {msg && <p className="mt-3 text-sm text-red-600">{msg}</p>}
        </div>
      </div>

      {/* Success Popup */}
      {successOrder && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">
            <div className="text-center">
              <div className="mx-auto mb-3 h-12 w-12 grid place-items-center rounded-full bg-emerald-100 text-emerald-700">
                ✓
              </div>
              <h3 className="text-lg font-semibold">Order placed successfully</h3>
              <p className="mt-1 text-sm text-gray-600">Order ID: <span className="font-mono">{successOrder.id}</span></p>
            </div>

            <div className="mt-5 grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                className="rounded-lg border py-2"
                onClick={() => setSuccessOrder(null)}
              >
                Close
              </button>
              <button
                className="rounded-lg border py-2"
                onClick={() => { setSuccessOrder(null); nav("/orders"); }}
              >
                Go to Orders
              </button>
              <button
                className="rounded-lg bg-gray-900 text-white py-2"
                onClick={() => { setSuccessOrder(null); nav(`/orders/${successOrder.id}`); }}
              >
                View Details
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
