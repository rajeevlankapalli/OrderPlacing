import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Layout from "../layout/Layout";
import api from "../api/client";

export default function OrderDetails() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [msg, setMsg] = useState("");

  useEffect(() => { (async () => {
    try {
      const r = await api.get(`/orders/${id}`);
      setOrder(r.data);
    } catch (e) {
      setMsg(e?.response?.data?.error || "Failed to load order");
    }
  })(); }, [id]);

  if (msg) return <Layout><p className="text-red-600">{msg}</p></Layout>;
  if (!order) return <Layout><p>Loading…</p></Layout>;

  return (
    <Layout>
      <div className="bg-white rounded-xl border p-4">
        <h2 className="text-lg font-semibold">Order #{order.id}</h2>
        <div className="text-sm text-gray-600">
          Placed: {new Date(order.createdAt).toLocaleString()}
        </div>

        <table className="mt-4 w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="py-2">Item</th>
              <th className="py-2">SKU</th>
              <th className="py-2">Qty</th>
              <th className="py-2">Unit</th>
              <th className="py-2 text-right">Line Total</th>
            </tr>
          </thead>
          <tbody>
            {order.items.map(li => (
              <tr key={li.id} className="border-b last:border-0">
                <td className="py-2">{li.item?.name}</td>
                <td className="py-2">{li.item?.sku}</td>
                <td className="py-2">{li.quantity}</td>
                <td className="py-2">₹ {Number(li.unitPrice).toLocaleString()}</td>
                <td className="py-2 text-right">₹ {Number(li.lineTotal).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan="4" className="py-2 text-right font-semibold">Total</td>
              <td className="py-2 text-right font-semibold text-indigo-700">
                ₹ {Number(order.totalAmount).toLocaleString()}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </Layout>
  );
}
