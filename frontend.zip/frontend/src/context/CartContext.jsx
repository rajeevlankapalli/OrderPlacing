import { createContext, useContext, useEffect, useMemo, useState } from "react";

const CartCtx = createContext(null);
export const useCart = () => useContext(CartCtx);

export default function CartProvider({ children }) {
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem("cart") || "[]"); }
    catch { return []; }
  });

  useEffect(() => { localStorage.setItem("cart", JSON.stringify(items)); }, [items]);

  function add(item, qty = 1) {
    qty = Math.max(1, Number(qty || 1));
    setItems(prev => {
      const i = prev.findIndex(p => p.itemId === item.id);
      if (i >= 0) {
        const nextQty = Math.min(prev[i].qty + qty, item.stock);
        const copy = [...prev];
        copy[i] = { ...copy[i], qty: nextQty };
        return copy;
      }
      return [...prev, {
        itemId: item.id,
        sku: item.sku,
        name: item.name,
        unitPrice: Number(item.price),
        stock: item.stock,
        qty: Math.min(qty, item.stock),
      }];
    });
  }

  function setQty(itemId, qty) {
    qty = Math.max(0, Number(qty || 0));
    setItems(prev => prev
      .map(p => p.itemId === itemId ? { ...p, qty: Math.min(qty, p.stock) } : p)
      .filter(p => p.qty > 0));
  }

  function remove(itemId) { setItems(prev => prev.filter(p => p.itemId !== itemId)); }
  function clear() { setItems([]); }

  const totals = useMemo(() => {
    const totalQty = items.reduce((a, it) => a + it.qty, 0);
    const totalAmount = items.reduce((a, it) => a + it.qty * it.unitPrice, 0);
    return { totalQty, totalAmount };
  }, [items]);

  const value = { items, add, setQty, remove, clear, totals };
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}
