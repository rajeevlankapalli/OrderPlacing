import { NavLink, useNavigate } from "react-router-dom";

function NavItem({ to, label, icon }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center gap-3 px-4 py-2 rounded-lg transition ${
          isActive ? "bg-indigo-600 text-white" : "text-gray-700 hover:bg-gray-100"
        }`
      }
    >
      <span>{icon}</span>
      <span className="font-medium">{label}</span>
    </NavLink>
  );
}

export default function Layout({ children }) {
  const nav = useNavigate();
  const user = (() => {
    try { return JSON.parse(localStorage.getItem("user") || "{}"); }
    catch { return {}; }
  })();

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("cart");
    nav("/login");
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b">
        <div className="mx-auto max-w-7xl px-6 h-14 flex items-center justify-between">
          <div className="font-semibold">OrderApp</div>
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600 hidden sm:block">
              {user?.name ? `Hi, ${user.name}` : ""}
            </div>
            <button
              onClick={logout}
              className="text-sm px-3 py-1.5 rounded-md bg-gray-900 text-white hover:bg-black transition"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-6 py-6 grid grid-cols-1 md:grid-cols-[240px_1fr] gap-6">
        {/* Sidebar */}
        <aside className="bg-white rounded-xl border p-4 h-fit md:sticky md:top-20">
          <nav className="flex flex-col gap-2">
            <NavItem to="/items"  label="Items"  icon="🛍️" />
            <NavItem to="/cart"   label="Cart"   icon="🧺" />
            <NavItem to="/orders" label="Orders" icon="📦" />
          </nav>
        </aside>

        {/* Content */}
        <main>{children}</main>
      </div>
    </div>
  );
}
