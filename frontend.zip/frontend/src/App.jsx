import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Items from "./pages/Items.jsx";
import Cart from "./pages/Cart.jsx";
import Orders from "./pages/Orders.jsx";
import OrderDetails from "./pages/OrderDetails.jsx";
import CartProvider from "./context/CartContext.jsx";

function Protected({ children }) {
  const token = localStorage.getItem("token");
  const loc = useLocation();
  return token ? children : <Navigate to="/login" replace state={{ from: loc }} />;
}

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 to-fuchsia-600">
      <CartProvider>
        <Routes>
          <Route path="/" element={<Navigate to="/items" />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          <Route path="/items" element={<Protected><Items /></Protected>} />
          <Route path="/cart" element={<Protected><Cart /></Protected>} />
          <Route path="/orders" element={<Protected><Orders /></Protected>} />
          <Route path="/orders/:id" element={<Protected><OrderDetails /></Protected>} />

          <Route path="*" element={<Navigate to="/items" />} />
        </Routes>
      </CartProvider>
    </div>
  );
}
